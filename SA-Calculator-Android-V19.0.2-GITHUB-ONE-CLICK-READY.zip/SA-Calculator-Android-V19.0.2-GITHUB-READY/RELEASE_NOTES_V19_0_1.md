# SA Calculator V19.0.1 — Android Build Fix

- Upgraded Android Gradle Plugin from 9.3.0 to 9.3.3.
- Retained Gradle 9.5.0, JDK 17, compileSdk/targetSdk 37, Build Tools 36.0.0, NDK 28.2.13676358 and CMake 3.22.1.
- Debug build now performs a clean build and emits plain Gradle diagnostics.
- Added Gradle configuration preflight.
- Added failure diagnostics for SDK/NDK/CMake/project inspection.
- Retained direct-ZIP and extracted-project support.
- Outputs: debug APK, unsigned release APK, release AAB.
