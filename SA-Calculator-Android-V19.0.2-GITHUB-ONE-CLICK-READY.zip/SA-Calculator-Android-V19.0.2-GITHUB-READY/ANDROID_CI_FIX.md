# Android CI Fix — V18.9.6

The GitHub Actions workflow intentionally does **not** use `android-actions/setup-android`.
GitHub-hosted Ubuntu runners already provide the Android SDK at `$ANDROID_HOME`; the workflow
uses the runner's `cmdline-tools/latest/bin/sdkmanager` directly, installs the exact SDK/NDK/CMake
versions required by AGP 9.3.0, validates the project layout, then builds both Debug and unsigned Release APKs.

Expected toolchain:
- JDK 17
- Android Gradle Plugin 9.3.0
- Gradle 9.5.0
- compileSdk 37
- Build Tools 36.0.0
- NDK 28.2.13676358
- CMake 3.22.1

The workflow produces two artifacts:
- `SA-Calculator-debug-apk`
- `SA-Calculator-release-unsigned-apk`

The release artifact is intentionally unsigned. A private signing key must never be committed to GitHub.
