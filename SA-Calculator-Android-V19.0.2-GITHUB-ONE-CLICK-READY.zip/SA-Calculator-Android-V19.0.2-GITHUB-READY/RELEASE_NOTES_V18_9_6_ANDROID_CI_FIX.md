# SA Calculator Android V18.9.7 — Android CI Fix

Focused release: no calculator feature expansion.

Fixed:
- Removed failing `android-actions/setup-android` dependency from GitHub Actions.
- Uses the GitHub-hosted runner's preinstalled Android SDK directly.
- Explicit SDK manager discovery and environment setup.
- Explicit license acceptance.
- Exact AGP 9.3 / Gradle 9.5 / API 37 / Build Tools 36.0.0 / NDK 28.2.13676358 / CMake 3.22.1 toolchain.
- Project-layout validation before Gradle build.
- Debug and unsigned-release APK output validation.
- Artifact upload fails loudly if an APK is missing.
- Workflow permissions and concurrency tightened.

Preserved:
- Native C++17 engine.
- 28-tool registry.
- Android native UI.
- JNI bridge.
- History/favorites/settings systems.
- No JS/HTML/CSS/WebView.
