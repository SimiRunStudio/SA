# SA Calculator V18.9.8 — Android CI SDK Resolver Fix

The previous GitHub Actions log showed `android-actions/setup-android@v3` failing while running sdkmanager from `cmdline-tools/16.0`.

This release removes `android-actions/setup-android@v3` entirely and uses the Android SDK tools already installed on the GitHub-hosted runner. The workflow resolves `sdkmanager` from `cmdline-tools/latest` or `cmdline-tools/16.0`, with a versioned fallback search.

The workflow also fails early if the old setup-android action is still present.

## Important upload rule

Do **not** upload this ZIP file itself as the repository contents. Extract it first, then upload the extracted files/folders so these paths are directly at repository root:

- `.github/workflows/android.yml`
- `app/`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`

After committing, start a new workflow run. The first SDK-related step should be `Resolve preinstalled Android SDK tools`, not `Set up Android SDK`.
